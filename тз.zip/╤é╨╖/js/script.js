    
    const flkty = new Flickity( '.main-carousel', {
    wrapAround: false,
    autoPlay: false,
    draggable: true,
    groupCells: 1,
    adaptiveHeight: true,
  });

  const currentYearSpan = document.getElementById('current-year');

        currentYearSpan.innerHTML = new Date().getFullYear();